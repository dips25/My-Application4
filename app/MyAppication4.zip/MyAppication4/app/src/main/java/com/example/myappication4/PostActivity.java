package com.example.myappication4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class PostActivity extends AppCompatActivity {

    private static final String TAG = PostActivity.class.getSimpleName();
    ArrayList<String> stringArrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        if (ContextCompat.checkSelfPermission(this , Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this , Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this , new String[]{Manifest.permission.READ_EXTERNAL_STORAGE , Manifest.permission.WRITE_EXTERNAL_STORAGE} , 100);
        } else {

            getAllImages();


        }


    }

    public void getAllImages() {

        File file = Environment.getExternalStorageDirectory();

        File picDir = new File(file , "DCIM");

        if (picDir.exists()) {

            Log.d(TAG, "getAllImages: " + picDir.list());

        }



        if (picDir.isDirectory()) {

            getSubDirectory(picDir);

        } else {

            getFiles(picDir);
        }


    }

    public void getFiles(File file) {

        File[] files = file.listFiles();

        for (int i = 0 ; i<files.length ; i++) {

            stringArrayList.add(files[i].getAbsolutePath());
            Log.d(TAG, "getAll: " + files[i].getAbsolutePath());

        }




    }

    public void getSubDirectory(File file) {

        File[] files = file.listFiles();



        for (int i = 0 ; i<file.list().length ; i++) {

            if (files[i].isDirectory()) {

                getSubDirectory(files[i]);

            } else if (files[i].isFile()) {

                stringArrayList.add(files[i].getAbsolutePath());


            }
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100) {

            if(grantResults.length > 0) {

                if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(this, "Permissions Granted", Toast.LENGTH_SHORT).show();


                }
            }



        }

    }
}